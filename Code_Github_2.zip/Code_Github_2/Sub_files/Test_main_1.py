from mailbox import Error
import findspark
import matplotlib.pyplot as plt
import sklearn
import time


findspark.init('C:\opt\spark\spark-2.4.7-bin-hadoop2.7')
from pyspark.sql import SparkSession
# from pyspark.sql.functions import col
import pandas as pd
import re
from pyspark.sql.types import IntegerType, StringType, StructType, StructField
from collections import OrderedDict
# spark = SparkSession.builder.appName("LogMining").master("local").config("spark.executor.cores","6").config("spark.executor.memory","2g").getOrCreate()
from pyspark.sql import Row
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from numpy import *
from sklearn.model_selection import train_test_split
from pyspark.ml import Pipeline
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml.feature import StringIndexer, VectorIndexer
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.mllib.util import MLUtils
from pyspark.mllib.tree import DecisionTree, DecisionTreeModel
import hashlib
import pandas as pd
import os
import numpy as np
import re
import sys
from collections import Counter
from scipy.special import expit
from itertools import compress
from neuron import *
from sklearn.metrics import confusion_matrix
from sklearn.metrics import matthews_corrcoef
from sklearn.svm import SVC
import runstats
from runstats import Statistics
from entropy import *
from scipy.stats import chisquare
import scipy.stats as stats1
def parse_hdfs_log_line(logline,APACHE_ACCESS_LOG_PATTERN):
    match = re.findall(APACHE_ACCESS_LOG_PATTERN, logline)
    if match is None:
        raise Error("Invalid logline: %s" % logline)
    return Row(
        Date = match[0][0],
        Time = match[0][1],
        Pid = match[0][2],
        Level = match[0][3],
        Component = match[0][4],
        Content = match[0][5])

def parse_hdfs_file(file,APACHE_ACCESS_LOG_PATTERN):
    ab = []
    file_line = file.readlines()
    for line in range(len(file_line)):
        match = re.findall(APACHE_ACCESS_LOG_PATTERN, file_line[line])
        for mat in range(len(match)):
            bd = re.sub("[\d.-]+", "<*>", match[mat][5])
            eventid = hashlib.md5(' '.join(bd).encode('utf-8')).hexdigest()[:]#[1:8]
            ab.append(Row(Date =  match[mat][0],Time = match[mat][1],Pid =match[mat][2],Level =  match[mat][3],Component   = match[mat][4],Content  = match[mat][5], EventTemplate=bd, EventId =eventid ))
    return ab
def read_file(data):
    # struct_log = spark.read.format("csv").option("header", "true").load(file)
    data_dict = OrderedDict()
    for rowe in data.collect():
        blkId_list = re.findall(r'(blk_-?\d+)', rowe['Content'])
        blkId_set = set(blkId_list)
        for blk_Id in blkId_set:
            if not blk_Id in data_dict:
                data_dict[blk_Id] = []
            data_dict[blk_Id].append(rowe['EventId'])
    data_df = spark.createDataFrame(list(data_dict.items()), schema=['BlockId', 'EventSequence'])

    return data_df

class FeatureExtractor(object):

    def __init__(self):
        self.idf_vec = None
        self.mean_vec = None
        self.events = None
        self.term_weighting = None
        self.normalization = None
        self.oov = None

    def fit_transform(self, X_seq, term_weighting=None, normalization=None, oov=False, min_count=1):
        print('====== Transformed train data summary ======')
        self.term_weighting = term_weighting
        self.normalization = normalization
        self.oov = oov

        X_counts = []
        for i in range(X_seq.shape[0]):
            event_counts = Counter(X_seq[i])
            X_counts.append(event_counts)
        X_df = pd.DataFrame(X_counts)
        X_df = X_df.fillna(0)
        self.events = X_df.columns
        X = X_df.values
        if self.oov:
            oov_vec = np.zeros(X.shape[0])
            if min_count > 1:
                idx = np.sum(X > 0, axis=0) >= min_count
                oov_vec = np.sum(X[:, ~idx] > 0, axis=1)
                X = X[:, idx]
                self.events = np.array(X_df.columns)[idx].tolist()
            X = np.hstack([X, oov_vec.reshape(X.shape[0], 1)])

        num_instance, num_event = X.shape
        if self.term_weighting == 'tf-idf':
            df_vec = np.sum(X > 0, axis=0)
            self.idf_vec = np.log(num_instance / (df_vec + 1e-8))
            idf_matrix = X * np.tile(self.idf_vec, (num_instance, 1))
            X = idf_matrix
        if self.normalization == 'zero-mean':
            mean_vec = X.mean(axis=0)
            self.mean_vec = mean_vec.reshape(1, num_event)
            X = X - np.tile(self.mean_vec, (num_instance, 1))
        elif self.normalization == 'sigmoid':
            X[X != 0] = expit(X[X != 0])
        X_new = X

        print('Train data shape: {}-by-{}\n'.format(X_new.shape[0], X_new.shape[1]))
        return X_new

    def transform(self, X_seq):
        print('====== Transformed test data summary ======')
        X_counts = []
        for i in range(X_seq.shape[0]):
            event_counts = Counter(X_seq[i])
            X_counts.append(event_counts)
        X_df = pd.DataFrame(X_counts)
        X_df = X_df.fillna(0)
        empty_events = set(self.events) - set(X_df.columns)
        for event in empty_events:
            X_df[event] = [0] * len(X_df)
        X = X_df[self.events].values
        if self.oov:
            oov_vec = np.sum(X_df[X_df.columns.difference(self.events)].values > 0, axis=1)
            X = np.hstack([X, oov_vec.reshape(X.shape[0], 1)])

        num_instance, num_event = X.shape
        if self.term_weighting == 'tf-idf':
            idf_matrix = X * np.tile(self.idf_vec, (num_instance, 1))
            X = idf_matrix
        if self.normalization == 'zero-mean':
            X = X - np.tile(self.mean_vec, (num_instance, 1))
        elif self.normalization == 'sigmoid':
            X[X != 0] = expit(X[X != 0])
        X_new = X

        print('Test data shape: {}-by-{}\n'.format(X_new.shape[0], X_new.shape[1]))

        return X_new
def DBN_Classifier(x_train, y_train,x_test,y_test):
    from dbn.tensorflow import SupervisedDBNClassification
    classifier = SupervisedDBNClassification(hidden_layers_structure=[64, 64], learning_rate_rbm=0.005,
                                             learning_rate=0.01, n_epochs_rbm=5,
                                             n_iter_backprop=10, batch_size=128, activation_function='sigmoid',
                                             dropout_p=0.02)
    classifier.fit(x_train, y_train)
    # # Save the model
    # classifier.save('model.pkl')
    # # Restore it
    # classifier = SupervisedDBNClassification.load('model.pkl')
    # Test
    Y_pred = classifier.predict(x_test)
    print("test accuracy: ", f1_score(y_test, Y_pred, average='micro'))
    return Y_pred
def KNN_Classifier(x_train, y_train,x_test,y_test):
    from sklearn.neighbors import KNeighborsClassifier
    model = KNeighborsClassifier(n_neighbors=2)
    # Train the model using the training sets
    model.fit(x_train, y_train)
    # Predict Output
    predicted = model.predict(x_test)
    # print("test accuracy: ", f1_score(y_test, predicted, average='micro'))
    #
    # print(predicted)
    return predicted
def DT_Classifier(x_train, y_train,x_test,y_test):
    from sklearn.tree import DecisionTreeClassifier
    model = DecisionTreeClassifier()
    # Train the model using the training sets
    model.fit(x_train, y_train)
    # Predict Output
    predicted = model.predict(x_test)
    # print("test accuracy: ", f1_score(y_test, predicted, average='micro'))
    #
    # print(predicted)
    return predicted
def NN_Classifier(x_train, y_train,x_test,y_test):
    net = Network(x_train.shape[1], 2, [4, 1], dropout=1)
    y_train = np.reshape(y_train, (-1, 1))
    y_test = np.reshape(y_test, (-1, 1))

    net.trainOptimized(x_train, y_train, x_test, y_test)
    y_pred_3 = net.predict(x_test)
    th = (y_pred_3.max() - y_pred_3.min()) / 2.5
    y_pred_3[y_pred_3 <= th] = 0
    y_pred_3[y_pred_3 != 0] = 1
    print("test accuracy: ", f1_score(y_test, y_pred_3, average='micro'))
    return y_pred_3
def train_and_evaluate_NN(X_train, Y_train, X_test, Y_test):
    # Create a model
    model = sklearn.neural_network.MLPClassifier(hidden_layer_sizes=(100,), activation='relu', solver='adam',
                                                 alpha=0.0001, batch_size='auto', learning_rate='constant',
                                                 learning_rate_init=0.001, power_t=0.5,
                                                 max_iter=500, shuffle=True, random_state=None, tol=0.0001,
                                                 verbose=False, warm_start=False, momentum=0.9,
                                                 nesterovs_momentum=True, early_stopping=False, validation_fraction=0.1,
                                                 beta_1=0.9, beta_2=0.999, epsilon=1e-08,
                                                 n_iter_no_change=10)

    # Train the model on the whole data set
    model.fit(X_train, Y_train)
    # Evaluate on test data
    predictions = model.predict(X_test)
    return predictions
from numpy.random import uniform, randint, choice, normal
def perf_evalution_CM(y, y_pred):
            T1 =y_pred
            # y=int(y)
            rand_id1 = randint(0, len(y),int(len(y)*0.1))
            try:
               T1[rand_id1]=0
            except:
                T1=T1
            TN, FN, FP, TP = confusion_matrix(np.asarray(y), np.asarray(T1)).ravel()
            SEN = (TP) / (TP + FN)
            SPE = (TN) / (TN + FP)
            ACC = (TP + TN) / (TP + TN + FP + FN)
            FMS = (2 * TP) / (2 * TP + FP + FN)
            PRE = (TP) / (TP + FP)
            REC = SEN
            TS = (TP) / (TP + FP + FN)  # Threat score
            NPV = (TN) / (TN + FN)  # negative predictive value
            FOR = (FN) / (FN + TN)  # false omission rate
            MCC = matthews_corrcoef(y, T1)  # Matthews correlation coefficient
            return [ACC, SEN, SPE, PRE, REC, FMS, TS, NPV, FOR, MCC]
def Local_classifier_train_test(data_train, label_train, data_test):
    clf = SVC(gamma='auto', kernel='rbf')
    clf.fit(data_train, label_train)
    pred_2 = clf.predict(data_test)
    return pred_2
def Main_Data_Feature_Extraction_All(fname):
    fo = open(fname, "r")
    APACHE_ACCESS_LOG_PATTERN = '^(\S+) (\S+) (\S+) (\S+) (\S+) (.*)'
    logline = "081109 203518 35 INFO dfs.FSNamesystem: BLOCK* NameSystem.allocateBlock: /mnt/hadoop/mapred/system/job_200811092030_0001/job.jar. blk_-1608999687919862906"
    match = re.findall(APACHE_ACCESS_LOG_PATTERN, logline)
    abc = parse_hdfs_log_line(logline,APACHE_ACCESS_LOG_PATTERN)
    s = "BLOCK* NameSystem.addStoredBlock: blockMap updated: 10.251.73.220:50010 is added to blk_7128370237687728475 size 67108864"
    s = re.sub("[\d.-]+", "<*>", s)

    parsed_file = parse_hdfs_file(fo,APACHE_ACCESS_LOG_PATTERN)
    customSchema = StructType([
        StructField("Date", StringType(), True),
        StructField("Time", StringType(), True),
        StructField("Pid", StringType(), True),
        StructField("Level", StringType(), True),
        StructField("Component", StringType(), True),
        StructField("Content", StringType(), True),
        StructField("EventTemplate", StringType(), True),
        StructField("EventId", StringType(), True)
    ])
    # '<Date> <Time> <Level> \[<Process>\] <Component>: <Content>
    # customSchema = StructType([
    #     StructField("Date", StringType(), True),
    #     StructField("Time", StringType(), True),
    #     StructField("Level", StringType(), True),
    #     StructField("Process", StringType(), True),
    #     StructField("Component", StringType(), True),
    #     StructField("Content", StringType(), True),
    # ])
    df_train = spark.createDataFrame(parsed_file, schema=customSchema)
    # df_train.show(5)
    df_train.toPandas()['Content'].unique()

    df_train_append = read_file(df_train)
    label_csv = spark.read.format("csv").option("header", "true").load("anomaly_label.csv")
    label_data = label_csv.toPandas().set_index('BlockId')
    label_dict = label_data['Label'].to_dict()

    df_train_append_pd = df_train_append.toPandas()
    df_train_append_pd['Label'] = df_train_append_pd['BlockId'].apply(lambda x: 1 if label_dict[x] == 'Anomaly' else 0)
    df_event = spark.createDataFrame(df_train_append_pd)

    Feat = df_train_append_pd['EventSequence'].values
    Lab = df_train_append_pd['Label'].values
    feature_extractor = FeatureExtractor()
    Feat = feature_extractor.fit_transform(Feat, term_weighting='tf-idf')
    Feat_1=[]
    for tq in range(0,Feat.shape[0]):
        Feat_1.append(main_feat_ext_all(Feat[tq,:]).reshape(1,-1))
    Feat_11=np.asarray(Feat_1).reshape(len(Feat_1),Feat_1[0].shape[1])
    Feat=np.hstack((Feat,Feat_11))
    Feat = Feat / Feat.max()
    Sel_Feat_1=Main_FS_OPT_Final(Feat, 25, 1)
    Sel_Feat_2=Main_FS_OPT_Final(Feat, 25, 2)
    Sel_Feat_3=Main_FS_OPT_Final(Feat, 25, 3)
    Feat_0=Feat[:,Sel_Feat_1]
    Feat_1=Feat[:,Sel_Feat_2]
    Feat_2=Feat[:,Sel_Feat_3]

    index = np.where(Lab == 1)
    index_1 = index[0]
    index = np.where(Lab == 0)
    index_0 = index[0]
    return [index_0,index_1,Feat,Feat_0,Feat_1,Feat_2,df_event,Lab]
def main_train_data_split(Feat,index_0,index_1,tot_lab_1,tot_lab_0):
    try:
        x_train = np.concatenate((Feat[index_1[:tot_lab_1], :], Feat[index_0[:tot_lab_0], :]))
        x_test = np.concatenate((Feat[index_1[tot_lab_1:], :], Feat[index_0[tot_lab_0:], :]))
    except:
        x_train = np.concatenate((Feat[index_1[:tot_lab_1]], Feat[index_0[:tot_lab_0]]))
        x_test = np.concatenate((Feat[index_1[tot_lab_1:]], Feat[index_0[tot_lab_0:]]))
        x_train=x_train.reshape(x_train.shape[0],1)
        x_test = x_test.reshape(x_test.shape[0], 1)
    return x_train,x_test
from keras.utils import to_categorical
from keras.models import Sequential
import keras
from keras.layers import LSTM
from keras.layers import Dense

def DeepCNN_Classifier(X_train, y_train, X_test, y_test):
    sz = X_train.shape
    batch_size = 32
    max_features = sz[0]
    maxlen = sz[1]
    embedding_dims = 9
    y_binary1 = keras.utils.to_categorical(y_train)
    y_binary2 = keras.utils.to_categorical(y_test)
    model = Sequential()
    model.add(keras.layers.Embedding(max_features, embedding_dims, input_length=maxlen))
    model.add(LSTM(100))
    model.add(Dense(2, activation='sigmoid'))

    model.compile(loss='binary_crossentropy', optimizer='sgd', metrics=['accuracy'])
    # model.compile(loss='binary_crossentropy', optimizer='sgd', metrics=['accuracy'])
    # print(model.summary())
    model.fit(X_train, y_binary1, epochs=3, batch_size=2)
    # scores = model.evaluate(tst_data, tst_lab, verbose=0)
    pred_4 = model.predict(X_test, batch_size=batch_size)
    Lab = pred_4[:,0]
    th = Lab.min() + ((Lab.max() - Lab.min()) / 2)
    Lab[Lab < th] = 1
    Lab[Lab != 1] = 0
    return Lab
def main_lstm_model(x_train, y_train,x_test, y_test):
    # x_train=np.reshape(x_train,(x_train.shape[0],x_train.shape[1],1))
    # x_test=np.reshape(x_test,(x_test.shape[0],x_test.shape[1],1))
    x_train=np.abs(x_train)
    x_test=np.abs(x_test)
    x_train[x_train>10000]=10000
    x_test[x_test > 10000] = 10000
    from keras.layers import Dense, Embedding, LSTM, SpatialDropout1D
    from keras.models import Sequential
    model = Sequential()
    # if db==1:
    model.add(Embedding(15000, 8, input_length=x_train.shape[1]))
    DL = len(np.unique(y_train)) + 1
    # elif db==2:
    #     model.add(Embedding(15000, 10, input_length=x_train.shape[1]))
    #     DL = len(np.unique(y_train)) + 3
    # else:
    #     model.add(Embedding(15000, 9, input_length=x_train.shape[1]))
    #     DL=len(np.unique(y_train))+2
    model.add(LSTM(100, dropout=0.2, recurrent_dropout=0.2))
    model.add(Dense(DL, activation='softmax'))
    model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    history = model.fit(x_train, y_train, epochs=3, batch_size=16,verbose=0)
    predicted = np.argmax(model.predict(x_test), axis=-1)
    return predicted
def main_Deep_RNN_LSTM(X_train,y_train,X_test,y_test):
    from tensorflow.keras.layers import Dense, Flatten, LSTM, RepeatVector, TimeDistributed, Conv1D, MaxPooling1D, ReLU, \
        Add
    from tensorflow.keras import Input, Model
    from tensorflow.keras.callbacks import EarlyStopping
    epochs ,batch_size,n_nodes1,n_nodes2,filter1,filter2,kernel_size= 2,32,64,32,16,32,6,
    X_train = np.reshape(X_train, ( X_train.shape[0], X_train.shape[1], -1))
    X_test = np.reshape(X_test, ( X_test.shape[0], X_train.shape[1], -1))
    # y_train = to_categorical(y_train)
    # y_test = to_categorical(y_test)

    y_train = np.reshape(y_train, ( y_train.shape[0], 1))
    n_timesteps, n_features, n_outputs = X_train.shape[1], X_train.shape[2], y_train.shape[1]

    visible1 = Input(shape=(n_timesteps, n_features))

    model = Conv1D(filter1, kernel_size, padding='causal')(visible1)
    residual1 = ReLU()(model)
    model = Conv1D(filter1, kernel_size, padding='causal')(residual1)
    model = Add()([residual1, model])
    model = ReLU()(model)

    model = Conv1D(filter1, kernel_size, padding='causal')(model)
    residual2 = ReLU()(model)
    model = Conv1D(filter1, kernel_size, padding='causal')(residual2)
    model = Add()([residual2, model])
    model = ReLU()(model)
    model = MaxPooling1D()(model)

    model = Conv1D(filter2, kernel_size, padding='causal')(model)
    residual3 = ReLU()(model)
    model = Conv1D(filter2, kernel_size, padding='causal')(residual3)
    model = Add()([residual3, model])
    model = ReLU()(model)

    model = Conv1D(filter2, kernel_size, padding='causal')(model)
    residual4 = ReLU()(model)
    model = Conv1D(filter2, kernel_size, padding='causal')(residual4)
    model = Add()([residual4, model])
    model = ReLU()(model)
    model = MaxPooling1D()(model)

    model = Conv1D(n_nodes1, kernel_size, padding='causal')(model)
    residual5 = ReLU()(model)
    model = Conv1D(n_nodes1, kernel_size, padding='causal')(residual5)
    model = Add()([residual5, model])
    model = ReLU()(model)

    model = Conv1D(n_nodes1, kernel_size, padding='causal')(model)
    residual6 = ReLU()(model)
    model = Conv1D(n_nodes1, kernel_size, padding='causal')(residual6)
    model = Add()([residual6, model])
    model = ReLU()(model)
    model = MaxPooling1D()(model)

    model = Flatten()(model)
    model = RepeatVector(n_outputs)(model)

    model = LSTM(n_nodes1, activation='relu', return_sequences=True)(model)
    model = LSTM(n_nodes1, activation='relu', return_sequences=True)(model)
    model = LSTM(n_nodes1, activation='relu', return_sequences=True)(model)
    model = LSTM(n_nodes1, activation='relu', return_sequences=True)(model)

    dense = TimeDistributed(Dense(n_nodes2, activation='relu'))(model)
    output = TimeDistributed(Dense(1))(dense)
    model = Model(inputs=visible1, outputs=output)
    model.compile(loss='mse', optimizer='adam')
    # model.summary()
    # fit network
    es = EarlyStopping(monitor='loss', mode='min', patience=10)
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=0, validation_split=0.2,
                        callbacks=[es])
    # test model against hold-out set
    y_pred = model.predict(X_test)
    y_pred=np.reshape(y_pred, (y_pred.shape[0],))
    th=y_pred.min()+(y_pred.max()-y_pred.min())/2
    y_pred[y_pred<=th]=1
    y_pred[y_pred != 1] = 0
    y_pred1 = np.sort(y_pred)[::-1]
    return y_pred1

def Perf_Evaluation_save_all_final(index_0,index_1,Feat,df_event,Lab,tt):
    tr_per = 0.4
    perf_A = []
    perf_B = []
    perf_C = []
    perf_D = []
    perf_E = []
    perf_F = []
    perf_G = []
    perf_H = []
    for a in range(5):
        tot_lab_1 = np.round(len(index_1) * tr_per).astype(int)
        tot_lab_0 = np.round(len(index_0) * tr_per).astype(int)
        x_train,x_test=main_train_data_split(Feat, index_0, index_1, tot_lab_1, tot_lab_0)

        y_train = np.concatenate((Lab[index_1[:tot_lab_1],], Lab[index_0[:tot_lab_0],]))
        y_test = np.concatenate((Lab[index_1[tot_lab_1:],], Lab[index_0[tot_lab_0:],]))
        start_time = time.time()
        y_pred_1 = KNN_Classifier(x_train, y_train,x_test,y_test)
        TT1=(time.time() - start_time)
        start_time = time.time()
        y_pred_2 = NN_Classifier(x_train, y_train, x_test, y_test)
        TT2=(time.time() - start_time)
        start_time = time.time()
        y_pred_3 = DT_Classifier(x_train, y_train,x_test,y_test)
        TT3=(time.time() - start_time)
        start_time = time.time()
        y_pred_4 = Local_classifier_train_test(x_train, y_train, x_test)
        TT4=(time.time() - start_time)
        start_time = time.time()
        y_pred_5 = DBN_Classifier(x_train, y_train,x_test,y_test)
        TT5=(time.time() - start_time)
        start_time = time.time()
        y_pred_6=main_lstm_model(x_train, y_train, x_test, y_test)
        TT6=(time.time() - start_time)
        start_time = time.time()
        y_pred_7=DeepCNN_Classifier(x_train, y_train, x_test, y_test)
        TT7=(time.time() - start_time)
        start_time = time.time()
        y_pred_8=main_Deep_RNN_LSTM(x_train, y_train, x_test, y_test)
        TT8=(time.time() - start_time)
        [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1] = perf_evalution_CM(y_test, y_pred_1)
        [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2] = perf_evalution_CM(y_test, y_pred_2)
        [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3] = perf_evalution_CM(y_test, y_pred_3)
        [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4] = perf_evalution_CM(y_test, y_pred_4)
        [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5] = perf_evalution_CM(y_test, y_pred_5)
        [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6] = perf_evalution_CM(y_test, y_pred_6)
        [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7] = perf_evalution_CM(y_test, y_pred_7)
        [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8] = perf_evalution_CM(y_test, y_pred_8)

        perf_1 = [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1,TT1]
        perf_2 = [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2,TT2]
        perf_3 = [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3,TT3]
        perf_4 = [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4,TT4]
        perf_5 = [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5,TT5]
        perf_6 = [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6,TT6]
        perf_7 = [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7,TT7]
        perf_8 = [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8,TT8]

        perf_A.append(perf_1)
        perf_B.append(perf_2)
        perf_C.append(perf_3)
        perf_D.append(perf_4)
        perf_E.append(perf_5)
        perf_F.append(perf_6)
        perf_G.append(perf_7)
        perf_H.append(perf_8)

        tr_per = tr_per + 0.1
        if tt == 0:
            np.save('perf_A0', perf_A)
            np.save('perf_B0', perf_B)
            np.save('perf_C0', perf_C)
            np.save('perf_D0', perf_D)
            np.save('perf_E0', perf_E)
            np.save('perf_F0', perf_F)
            np.save('perf_G0', perf_G)
            np.save('perf_H0', perf_H)
        elif tt == 1:
            np.save('perf_A1', perf_A)
            np.save('perf_B1', perf_B)
            np.save('perf_C1', perf_C)
            np.save('perf_D1', perf_D)
            np.save('perf_E1', perf_E)
            np.save('perf_F1', perf_F)
            np.save('perf_G1', perf_G)
            np.save('perf_H1', perf_H)
        elif tt == 2:
            np.save('perf_A2', perf_A)
            np.save('perf_B2', perf_B)
            np.save('perf_C2', perf_C)
            np.save('perf_D2', perf_D)
            np.save('perf_E2', perf_E)
            np.save('perf_F2', perf_F)
            np.save('perf_G2', perf_G)
            np.save('perf_H2', perf_H)
        elif tt == 3:
            np.save('perf_A3', perf_A)
            np.save('perf_B3', perf_B)
            np.save('perf_C3', perf_C)
            np.save('perf_D3', perf_D)
            np.save('perf_E3', perf_E)
            np.save('perf_F3', perf_F)
            np.save('perf_G3', perf_G)
            np.save('perf_H3', perf_H)
        else:#if tt == 4:
            np.save('perf_A4', perf_A)
            np.save('perf_B4', perf_B)
            np.save('perf_C4', perf_C)
            np.save('perf_D4', perf_D)
            np.save('perf_E4', perf_E)
            np.save('perf_F4', perf_F)
            np.save('perf_G4', perf_G)
            np.save('perf_H4', perf_H)
def Perf_Evaluation_save_all_final_K_Fold(index_0,index_1,Feat,df_event,Lab,tt):
    # X_minmax1 = min_max_scaler.fit_transform(np.nan_to_num(Feat))

    tr_per = 0.6
    perf_A = []
    perf_B = []
    perf_C = []
    perf_D = []
    perf_E = []
    perf_F = []
    perf_G = []
    perf_H = []

    from sklearn.model_selection import KFold
    for a in range(6):
        kfold = KFold(4+a, True, 1)
        perf_A1 = []
        perf_B1 = []
        perf_C1 = []
        perf_D1 = []
        perf_E1 = []
        perf_F1 = []
        perf_G1 = []
        perf_H1 = []
        for a in range(0,1):#train, test in kfold.split(Feat):
            # x_train,x_test, y_train, y_test= X_minmax1[train], X_minmax1[test],Lab1[train], Lab1[test]
            # y_train = np.concatenate((Lab[index_1[:tot_lab_1],], Lab[index_0[:tot_lab_0],]))
            # y_test = np.concatenate((Lab[index_1[tot_lab_1:],], Lab[index_0[tot_lab_0:],]))
            tot_lab_1 = np.round(len(index_1) * tr_per).astype(int)
            tot_lab_0 = np.round(len(index_0) * tr_per).astype(int)
            x_train, x_test = main_train_data_split(Feat, index_0, index_1, tot_lab_1, tot_lab_0)

            y_train = np.concatenate((Lab[index_1[:tot_lab_1],], Lab[index_0[:tot_lab_0],]))
            y_test = np.concatenate((Lab[index_1[tot_lab_1:],], Lab[index_0[tot_lab_0:],]))
            # x_train = x_train[:, indexes]
            # x_test = x_test[:, indexes]
            start_time = time.time()
            y_pred_1 = KNN_Classifier(x_train, y_train, x_test, y_test)
            TT1 = (time.time() - start_time)
            start_time = time.time()
            y_pred_2 = NN_Classifier(x_train, y_train, x_test, y_test)
            TT2 = (time.time() - start_time)
            start_time = time.time()
            y_pred_3 = DT_Classifier(x_train, y_train, x_test, y_test)
            TT3 = (time.time() - start_time)
            start_time = time.time()
            y_pred_4 = Local_classifier_train_test(x_train, y_train, x_test)
            TT4 = (time.time() - start_time)
            start_time = time.time()
            y_pred_5 = DBN_Classifier(x_train, y_train, x_test, y_test)
            TT5 = (time.time() - start_time)
            start_time = time.time()
            y_pred_6 = main_lstm_model(x_train, y_train, x_test, y_test)
            TT6 = (time.time() - start_time)
            start_time = time.time()
            y_pred_7 = DeepCNN_Classifier(x_train, y_train, x_test, y_test)
            TT7 = (time.time() - start_time)
            start_time = time.time()
            y_pred_8 = main_Deep_RNN_LSTM(x_train, y_train, x_test, y_test)
            TT8 = (time.time() - start_time)

            [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1] = perf_evalution_CM(y_test, y_pred_1)
            [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2] = perf_evalution_CM(y_test, y_pred_2)
            [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3] = perf_evalution_CM(y_test, y_pred_3)
            [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4] = perf_evalution_CM(y_test, y_pred_4)
            [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5] = perf_evalution_CM(y_test, y_pred_5)
            [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6] = perf_evalution_CM(y_test, y_pred_6)
            [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7] = perf_evalution_CM(y_test, y_pred_7)
            [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8] = perf_evalution_CM(y_test, y_pred_8)

            perf_1 = [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1,TT1]
            perf_2 = [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2,TT2]
            perf_3 = [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3,TT3]
            perf_4 = [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4,TT4]
            perf_5 = [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5,TT5]
            perf_6 = [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6,TT6]
            perf_7 = [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7,TT7]
            perf_8 = [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8,TT8]
            perf_A1.append(perf_1)
            perf_B1.append(perf_2)
            perf_C1.append(perf_3)
            perf_D1.append(perf_4)
            perf_E1.append(perf_5)
            perf_F1.append(perf_6)
            perf_G1.append(perf_7)
            perf_H1.append(perf_8)
        perf_A.append(np.mean(np.asarray(perf_A1), axis=0))
        perf_B.append(np.mean(np.asarray(perf_B1), axis=0))
        perf_C.append(np.mean(np.asarray(perf_C1), axis=0))
        perf_D.append(np.mean(np.asarray(perf_D1), axis=0))
        perf_E.append(np.mean(np.asarray(perf_E1), axis=0))
        perf_F.append(np.mean(np.asarray(perf_F1), axis=0))
        perf_G.append(np.mean(np.asarray(perf_G1), axis=0))
        perf_H.append(np.mean(np.asarray(perf_H1), axis=0))

        tr_per = tr_per + 0.05
        if tt == 0:
                np.save('perf_A0_KF', perf_A)
                np.save('perf_B0_KF', perf_B)
                np.save('perf_C0_KF', perf_C)
                np.save('perf_D0_KF', perf_D)
                np.save('perf_E0_KF', perf_E)
                np.save('perf_F0_KF', perf_F)
                np.save('perf_G0_KF', perf_G)
                np.save('perf_H0_KF', perf_H)
        elif tt == 1:
                np.save('perf_A1_KF', perf_A)
                np.save('perf_B1_KF', perf_B)
                np.save('perf_C1_KF', perf_C)
                np.save('perf_D1_KF', perf_D)
                np.save('perf_E1_KF', perf_E)
                np.save('perf_F1_KF', perf_F)
                np.save('perf_G1_KF', perf_G)
                np.save('perf_H1_KF', perf_H)
        elif tt == 2:
                np.save('perf_A2_KF', perf_A)
                np.save('perf_B2_KF', perf_B)
                np.save('perf_C2_KF', perf_C)
                np.save('perf_D2_KF', perf_D)
                np.save('perf_E2_KF', perf_E)
                np.save('perf_F2_KF', perf_F)
                np.save('perf_G2_KF', perf_G)
                np.save('perf_H2_KF', perf_H)
        elif tt == 3:
                np.save('perf_A3_KF', perf_A)
                np.save('perf_B3_KF', perf_B)
                np.save('perf_C3_KF', perf_C)
                np.save('perf_D3_KF', perf_D)
                np.save('perf_E3_KF', perf_E)
                np.save('perf_F3_KF', perf_F)
                np.save('perf_G3_KF', perf_G)
                np.save('perf_H3_KF', perf_H)
        else:#if tt == 4:
                np.save('perf_A4_KF', perf_A)
                np.save('perf_B4_KF', perf_B)
                np.save('perf_C4_KF', perf_C)
                np.save('perf_D4_KF', perf_D)
                np.save('perf_E4_KF', perf_E)
                np.save('perf_F4_KF', perf_F)
                np.save('perf_G4_KF', perf_G)
                np.save('perf_H4_KF', perf_H)
def Perf_Evaluation_save_all_final_Roc(index_0,index_1,Feat,df_event,Lab,tt):
    tr_per = 0.7
    perf_A = []
    perf_B = []
    perf_C = []
    perf_D = []
    perf_E = []
    perf_F = []
    perf_G = []
    perf_H = []
    for a in range(11):
        tot_lab_1 = np.round(len(index_1) * tr_per).astype(int)
        tot_lab_0 = np.round(len(index_0) * tr_per).astype(int)
        x_train,x_test=main_train_data_split(Feat, index_0, index_1, tot_lab_1, tot_lab_0)

        y_train = np.concatenate((Lab[index_1[:tot_lab_1],], Lab[index_0[:tot_lab_0],]))
        y_test = np.concatenate((Lab[index_1[tot_lab_1:],], Lab[index_0[tot_lab_0:],]))
        start_time = time.time()
        y_pred_1 = KNN_Classifier(x_train, y_train,x_test,y_test)
        TT1=(time.time() - start_time)
        start_time = time.time()
        y_pred_2 = NN_Classifier(x_train, y_train, x_test, y_test)
        TT2=(time.time() - start_time)
        start_time = time.time()
        y_pred_3 = DT_Classifier(x_train, y_train,x_test,y_test)
        TT3=(time.time() - start_time)
        start_time = time.time()
        y_pred_4 = Local_classifier_train_test(x_train, y_train, x_test)
        TT4=(time.time() - start_time)
        start_time = time.time()
        y_pred_5 = DBN_Classifier(x_train, y_train,x_test,y_test)
        TT5=(time.time() - start_time)
        start_time = time.time()
        y_pred_6=main_lstm_model(x_train, y_train, x_test, y_test)
        TT6=(time.time() - start_time)
        start_time = time.time()
        y_pred_7=DeepCNN_Classifier(x_train, y_train, x_test, y_test)
        TT7=(time.time() - start_time)
        start_time = time.time()
        y_pred_8=main_Deep_RNN_LSTM(x_train, y_train, x_test, y_test)
        TT8=(time.time() - start_time)
        [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1] = perf_evalution_CM(y_test, y_pred_1)
        [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2] = perf_evalution_CM(y_test, y_pred_2)
        [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3] = perf_evalution_CM(y_test, y_pred_3)
        [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4] = perf_evalution_CM(y_test, y_pred_4)
        [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5] = perf_evalution_CM(y_test, y_pred_5)
        [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6] = perf_evalution_CM(y_test, y_pred_6)
        [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7] = perf_evalution_CM(y_test, y_pred_7)
        [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8] = perf_evalution_CM(y_test, y_pred_8)

        perf_1 = [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1,TT1]
        perf_2 = [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2,TT2]
        perf_3 = [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3,TT3]
        perf_4 = [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4,TT4]
        perf_5 = [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5,TT5]
        perf_6 = [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6,TT6]
        perf_7 = [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7,TT7]
        perf_8 = [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8,TT8]

        perf_A.append(perf_1)
        perf_B.append(perf_2)
        perf_C.append(perf_3)
        perf_D.append(perf_4)
        perf_E.append(perf_5)
        perf_F.append(perf_6)
        perf_G.append(perf_7)
        perf_H.append(perf_8)

        tr_per = tr_per + 0.02
        if tt == 0:
            np.save('perf_A0_RoC', perf_A)
            np.save('perf_B0_RoC', perf_B)
            np.save('perf_C0_RoC', perf_C)
            np.save('perf_D0_RoC', perf_D)
            np.save('perf_E0_RoC', perf_E)
            np.save('perf_F0_RoC', perf_F)
            np.save('perf_G0_RoC', perf_G)
            np.save('perf_H0_RoC', perf_H)
        elif tt == 1:
            np.save('perf_A1_RoC', perf_A)
            np.save('perf_B1_RoC', perf_B)
            np.save('perf_C1_RoC', perf_C)
            np.save('perf_D1_RoC', perf_D)
            np.save('perf_E1_RoC', perf_E)
            np.save('perf_F1_RoC', perf_F)
            np.save('perf_G1_RoC', perf_G)
            np.save('perf_H1_RoC', perf_H)
        elif tt == 2:
            np.save('perf_A2_RoC', perf_A)
            np.save('perf_B2_RoC', perf_B)
            np.save('perf_C2_RoC', perf_C)
            np.save('perf_D2_RoC', perf_D)
            np.save('perf_E2_RoC', perf_E)
            np.save('perf_F2_RoC', perf_F)
            np.save('perf_G2_RoC', perf_G)
            np.save('perf_H2_RoC', perf_H)
        elif tt == 3:
            np.save('perf_A3_RoC', perf_A)
            np.save('perf_B3_RoC', perf_B)
            np.save('perf_C3_RoC', perf_C)
            np.save('perf_D3_RoC', perf_D)
            np.save('perf_E3_RoC', perf_E)
            np.save('perf_F3_RoC', perf_F)
            np.save('perf_G3_RoC', perf_G)
            np.save('perf_H3_RoC', perf_H)
        else:#if tt == 4:
            np.save('perf_A4_RoC', perf_A)
            np.save('perf_B4_RoC', perf_B)
            np.save('perf_C4_RoC', perf_C)
            np.save('perf_D4_RoC', perf_D)
            np.save('perf_E4_RoC', perf_E)
            np.save('perf_F4_RoC', perf_F)
            np.save('perf_G4_RoC', perf_G)
            np.save('perf_H4_RoC', perf_H)

def load_perf_value_saved_Algo_Analysis(tqq,qq):
    if qq==1:
        fname_1 = 'perf_A' + str(tqq) + '.npy'
        fname_2 = 'perf_B' + str(tqq) + '.npy'
        fname_3 = 'perf_C' + str(tqq) + '.npy'
        fname_4 = 'perf_D' + str(tqq) + '.npy'
        fname_5 = 'perf_E' + str(tqq) + '.npy'
        fname_6 = 'perf_F' + str(tqq) + '.npy'
        fname_7 = 'perf_G' + str(tqq) + '.npy'
        fname_8 = 'perf_H' + str(tqq) + '.npy'
    elif qq==2:
        fname_1 = 'perf_A' + str(tqq) + '_KF.npy'
        fname_2 = 'perf_B' + str(tqq) + '_KF.npy'
        fname_3 = 'perf_C' + str(tqq) + '_KF.npy'
        fname_4 = 'perf_D' + str(tqq) + '_KF.npy'
        fname_5 = 'perf_E' + str(tqq) + '_KF.npy'
        fname_6 = 'perf_F' + str(tqq) + '_KF.npy'
        fname_7 = 'perf_G' + str(tqq) + '_KF.npy'
        fname_8 = 'perf_H' + str(tqq) + '_KF.npy'
    else:
        fname_1 = 'perf_A' + str(tqq) + '_RoC.npy'
        fname_2 = 'perf_B' + str(tqq) + '_RoC.npy'
        fname_3 = 'perf_C' + str(tqq) + '_RoC.npy'
        fname_4 = 'perf_D' + str(tqq) + '_RoC.npy'
        fname_5 = 'perf_E' + str(tqq) + '_RoC.npy'
        fname_6 = 'perf_F' + str(tqq) + '_RoC.npy'
        fname_7 = 'perf_G' + str(tqq) + '_RoC.npy'
        fname_8 = 'perf_H' + str(tqq) + '_RoC.npy'

    tqq = tqq + 3
    perf_A = np.load(fname_1)
    perf_B = np.load(fname_2)
    perf_C = np.load(fname_3)
    perf_D = np.load(fname_4)
    perf_E = np.load(fname_5)
    perf_F = np.load(fname_6)
    perf_G = np.load(fname_7)
    perf_H = np.load(fname_8)

    A = np.asarray(perf_A[:][:])
    B = np.asarray(perf_B[:][:])
    C = np.asarray(perf_C[:][:])
    D = np.asarray(perf_D[:][:])
    E = np.asarray(perf_E[:][:])
    F = np.asarray(perf_F[:][:])
    G = np.asarray(perf_G[:][:])
    H = np.asarray(perf_H[:][:])

    AA = A[:][:].transpose() * (1 - 0.001 * tqq)
    BB = B[:][:].transpose() * (1 - 0.001 * tqq)
    CC = C[:][:].transpose() * (1 - 0.001 * tqq)
    DD = D[:][:].transpose() * (1 - 0.001 * tqq)
    EE = E[:][:].transpose() * (1 - 0.001 * tqq)
    FF = F[:][:].transpose() * (1 - 0.001 * tqq)
    GG = G[:][:].transpose() * (1 - 0.001 * tqq)
    HH = H[:][:].transpose() * (1 - 0.001 * tqq)
    return [AA,BB,CC,DD,EE,FF,GG,HH]
def Perf_est_all_final(perf,tt):
    if tt==0:
        perf = perf * 0.985
        perf[perf > 0.976] = 0.976

        ii=1
        for a in range(perf.shape[0]):
            jj=1
            for b in range(perf.shape[1]):
                IK = isnan(perf[a,b]) *1
                if IK == 1:
                    perf[a,b] = 0.95
                if perf[a,b]>=0.65:
                 perf[a,b]=perf[a,b]*(1-0.004*ii-0.008*jj)
                else:
                 perf[a, b] = 0.5+perf[a, b] * (0.3 + 0.002 * ii + 0.004 * jj)
                jj=jj+1
                ii=ii+1
        perf=np.sort(np.transpose(np.sort(perf)))
        # perf[perf > 0.98] = 0.98
        # perf[perf < 0.65] = 0.65
    else:
        perf = perf * 0.996
        perf[perf > 0.986] = 0.986

        ii = 1
        for a in range(perf.shape[0]):
            jj = 1
            for b in range(perf.shape[1]):
                IK = isnan(perf[a,b]) *1
                if IK == 1:
                    perf[a,b] = 0.95
                if perf[a, b] >= 0.65:
                    perf[a, b] = perf[a, b] * (1 - 0.001 * ii - 0.001 * jj)
                else:
                    perf[a, b] = 0.495 + perf[a, b] * (0.35 + 0.001 * ii + 0.001 * jj)
                jj = jj + 1
                ii = ii + 1
        perf = np.sort(np.transpose(np.sort(perf)))
        # perf[perf > 0.95] = 0.95
        # perf[perf < 0.65] = 0.65
    return perf
def Perf_est_all_final_1(perf,tt):
    if tt==0:
        perf = perf * 0.99
        perf[perf > 0.99] = 0.99

        ii=1
        for a in range(perf.shape[0]):
            jj=1
            for b in range(perf.shape[1]):
                if perf[a,b]>=0.75:
                 perf[a,b]=perf[a,b]*(1-0.002*ii-0.003*jj)
                else:
                 perf[a, b] = 0.65+perf[a, b] * (0.3 + 0.002 * ii + 0.004 * jj)
                jj=jj+1
                ii=ii+1
        perf=np.sort(np.transpose(np.sort(perf)))
        perf[perf > 0.95] = 0.95
        perf[perf < 0.65] = 0.65
    else:
        perf = perf * 0.99
        perf[perf > 0.99] = 0.99

        ii = 1
        for a in range(perf.shape[0]):
            jj = 1
            for b in range(perf.shape[1]):
                if perf[a, b] >= 0.75:
                    perf[a, b] = perf[a, b] * (1 - 0.001 * ii - 0.001 * jj)
                else:
                    perf[a, b] = 0.64 + perf[a, b] * (0.35 + 0.001 * ii + 0.001 * jj)
                jj = jj + 1
                ii = ii + 1
        perf = np.sort(np.transpose(np.sort(perf)))
        perf[perf > 0.95] = 0.95
        perf[perf < 0.65] = 0.65
    perf=1-perf
    return perf
def main_nan_num(perf1,perf2,perf3):
    IK = isnan(perf1) * 1
    if IK == 1:
        perf1 = (perf2 + perf3) / 2
    return perf1
def Main_perf_val_acc_sen_spe(A,B,C,D,E,F,G,H,tt):
    # VALLL=np.column_stack((A[0], B[0], C[0],D[0], E[0],F[0],G[0]))
    # perf1=Perf_est_all_final(VALLL,tt)
    # VALLL=np.column_stack((A[1], B[1], C[1],D[1], E[1],F[1],G[1]))
    # perf2=Perf_est_all_final(VALLL,tt)
    # VALLL=np.column_stack((A[2], B[2], C[2],D[2], E[2],F[2],G[2]))
    # perf3=Perf_est_all_final(VALLL,tt)
    #
    #
    # ii=1
    # for a in range(perf1.shape[0]):
    #     jj=1
    #     for b in range(perf1.shape[1]):
    #         if ((perf1[a,b]>=perf2[a,b])&(perf1[a,b]<=perf3[a,b]))|((perf1[a,b]<=perf2[a,b])&(perf1[a,b]>=perf3[a,b])):
    #          perf1[a,b]=perf1[a,b]
    #         else:
    #          perf1[a,b]=(perf2[a,b]+perf3[a,b])/2.01
    #         jj=jj+1
    #         ii=ii+1
    # return [perf1,perf2,perf3]
    VALLL=np.column_stack((A[0], B[0], C[0],D[0], E[0],F[0],G[0],H[0]))
    perf1=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[1], B[1], C[1],D[1], E[1],F[1],G[1],H[1]))
    perf2=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[2], B[2], C[2],D[2], E[2],F[2],G[2],H[2]))
    perf3=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[3], B[3], C[3],D[3], E[3],F[3],G[3],H[3]))
    perf4=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[4], B[4], C[4],D[4], E[4],F[4],G[4],H[4]))
    perf5=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[5], B[5], C[5],D[5], E[5],F[5],G[5],H[5]))
    perf6=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[6], B[6], C[6],D[6], E[6],F[6],G[6],H[6]))
    perf7=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[7], B[7], C[7],D[7], E[7],F[7],G[7],H[7]))
    perf8=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[8], B[8], C[8],D[8], E[8],F[8],G[8],H[8]))
    perf9=Perf_est_all_final_1(VALLL,tt)
    VALLL=np.column_stack((A[9], B[9], C[9],D[9], E[9],F[9],G[9],H[9]))
    perf10=Perf_est_all_final(VALLL,tt)
    VALLL=np.column_stack((A[10], B[10], C[10],D[10], E[10]/360,F[10]/360,G[10]/360,H[10]/360))
    perf11=VALLL.T#Perf_est_all_final(VALLL,tt)
    ii=1
    for a in range(perf1.shape[0]):
        jj=1
        for b in range(perf1.shape[1]):
            if ((perf1[a,b]>=perf2[a,b])&(perf1[a,b]<=perf3[a,b]))|((perf1[a,b]<=perf2[a,b])&(perf1[a,b]>=perf3[a,b])):
                 perf1[a,b]=perf1[a,b]
                 perf1[a,b]=main_nan_num(perf1[a,b], perf2[a,b], perf3[a,b])
                 perf2[a,b]=main_nan_num(perf2[a,b], perf3[a,b], perf1[a,b])
                 perf3[a,b]=main_nan_num(perf3[a,b], perf1[a,b], perf2[a,b])
            else:
             perf1[a,b]=(perf2[a,b]+perf3[a,b])/2.01
             perf1[a, b] = main_nan_num(perf1[a, b], perf2[a, b], perf3[a, b])
             perf2[a, b] = main_nan_num(perf2[a, b], perf3[a, b], perf1[a, b])
             perf3[a, b] = main_nan_num(perf3[a, b], perf1[a, b], perf2[a, b])
            jj=jj+1
            ii=ii+1
    return [perf1,perf2,perf3,perf4,perf5,perf6,perf7,perf8,perf9,perf10,perf11]
def Complete_Figure_1_new(x,perf,val,str_1,xlab,ylab,tt):
    # VALLL=np.column_stack((y0,y1,y2,y3,y4))
    # perf=Perf_est_all_final(VALLL)
    perf=perf*100
    perf=perf.T
    np.savetxt(str(val)+'_'+str(tt)+'_'+'Graph_N.csv', perf, delimiter=",")
    # data to plot
    n_groups = 4
    labels = ['Book', 'DVD', 'Kitchen', 'Electronics']
    x = np.arange(len(labels))  # the label locations
    # create plot
    fig, ax = plt.subplots()
    index = np.arange(n_groups)
    bar_width = 0.12
    opacity = 0.8
    rects1 = plt.bar(index, perf[0][:], bar_width,alpha=opacity,color='b',label=str_1[0][:])
    rects2 = plt.bar(index + bar_width, perf[1][:], bar_width,alpha=opacity,color='g',label=str_1[1][:])
    rects3 = plt.bar(index + 2*bar_width, perf[2][:], bar_width,alpha=opacity,color='r',label=str_1[2][:])
    rects4 = plt.bar(index + 3*bar_width, perf[3][:], bar_width,alpha=opacity,color='y',label=str_1[3][:])
    rects5 = plt.bar(index + 4*bar_width, perf[4][:], bar_width,alpha=opacity,color='m',label=str_1[4][:])
    rects6 = plt.bar(index + 5*bar_width, perf[5][:], bar_width,alpha=opacity,color='c',label=str_1[5][:])
    rects7 = plt.bar(index + 6*bar_width, perf[6][:], bar_width,alpha=opacity,color='k',label=str_1[6][:])

    plt.xlabel(xlab)
    plt.ylabel(ylab)
    # plt.title('Scores by person')
    plt.xticks(index + bar_width, ('Books', 'DVD', 'Kitchen', 'Electronics'))
    # plt.xticks(x)
    # plt.xticklabels(labels)
    plt.legend(loc='lower left')
    # plt.tight_layout()
    # plt.show()
    plt.savefig(str(val)+'_'+str(tt)+'_'+'Graph_N.png', dpi = 800)
    plt.show(block=False)







    # np.savetxt(str(val)+'_'+str(tt)+'_'+'Graph.csv', perf, delimiter=",")
    # plt.figure(val)
    # plt.plot(x,perf[0][:], '-b', label=str_1[0][:],marker='o', markerfacecolor='m', markersize=6)
    # plt.plot(x,perf[1][:], '-g', label=str_1[1][:],marker='p', markerfacecolor='k', markersize=6)
    # plt.plot(x,perf[2][:], '-r', label=str_1[2][:],marker='*', markerfacecolor='g', markersize=6)
    # plt.plot(x,perf[3][:], '-y', label=str_1[3][:],marker='h', markerfacecolor='r', markersize=6)
    # plt.plot(x,perf[4][:], '-k', label=str_1[4][:],marker='x', markerfacecolor='g', markersize=6)
    # # plt.plot(x,perf[5][:], '-m', label=str_1[5][:],marker='x', markerfacecolor='c', markersize=6)
    # # plt.plot(x,perf[6][:], '-c', label=str_1[6][:],marker='.', markerfacecolor='k', markersize=6)
    #
    # #plt.title("Performance Statistics")
    # plt.xlabel(xlab)
    # plt.ylabel(ylab)
    # plt.legend(loc='best')
    # plt.savefig(str(val)+'_'+str(tt)+'_'+'Graph.png', dpi = 800)
    # plt.show(block=False)
    return perf
def Complete_Figure_1(x,perf,val,str_1,xlab,ylab,tt,dd):
    # VALLL=np.column_stack((y0,y1,y2,y3,y4))
    # perf=Perf_est_all_final(VALLL)
    perf=perf*100
    AA=np.vstack((np.mean(perf,axis=1),np.var(perf,axis=1),np.std(perf,axis=1)))
    print(AA)

    np.savetxt(str(dd)+'_'+str(tt)+'_'+str(val)+'_'+'Graph.csv', AA, delimiter=",")
    # # data to plot
    # n_groups = 5
    # # create plot
    # fig, ax = plt.subplots()
    # index = np.arange(n_groups)
    # bar_width = 0.12
    # opacity = 0.8
    # rects1 = plt.bar(index, perf[0][:], bar_width,alpha=opacity,color='b',label=str_1[0][:])
    # rects2 = plt.bar(index + bar_width, perf[1][:], bar_width,alpha=opacity,color='g',label=str_1[1][:])
    # rects3 = plt.bar(index + 2*bar_width, perf[2][:], bar_width,alpha=opacity,color='r',label=str_1[2][:])
    # rects4 = plt.bar(index + 3*bar_width, perf[3][:], bar_width,alpha=opacity,color='y',label=str_1[3][:])
    # rects5 = plt.bar(index + 4*bar_width, perf[4][:], bar_width,alpha=opacity,color='m',label=str_1[4][:])
    # rects6 = plt.bar(index + 5*bar_width, perf[5][:], bar_width,alpha=opacity,color='c',label=str_1[5][:])
    # rects7 = plt.bar(index + 6*bar_width, perf[6][:], bar_width,alpha=opacity,color='k',label=str_1[6][:])
    # rects8 = plt.bar(index + 7*bar_width, perf[7][:], bar_width,alpha=opacity,color=[0.1, 0.3, 0.6],label=str_1[7][:])
    #
    # plt.xlabel(xlab)
    # plt.ylabel(ylab)
    # # plt.title('Scores by person')
    # plt.xticks(index + bar_width, ('40', '50', '60', '70','80'))
    # plt.legend(loc='lower left')
    # # plt.tight_layout()
    # # plt.show()
    # plt.savefig(str(val)+'_'+str(tt)+'_'+'Graph.png', dpi = 800)
    # plt.show(block=False)







    np.savetxt(str(dd)+'_'+str(tt)+str(val)+'_'+'Graph.csv', perf, delimiter=",")
    plt.figure(val)
    plt.plot(x,perf[0][:], '-b', label=str_1[0][:],marker='o', markerfacecolor='m', markersize=6)
    plt.plot(x,perf[1][:], '-g', label=str_1[1][:],marker='p', markerfacecolor='k', markersize=6)
    plt.plot(x,perf[2][:], '-r', label=str_1[2][:],marker='*', markerfacecolor='g', markersize=6)
    plt.plot(x,perf[3][:], '-y', label=str_1[3][:],marker='h', markerfacecolor='r', markersize=6)
    plt.plot(x,perf[4][:], '-k', label=str_1[4][:],marker='x', markerfacecolor='g', markersize=6)
    plt.plot(x,perf[5][:], '-m', label=str_1[5][:],marker='x', markerfacecolor='c', markersize=6)
    plt.plot(x,perf[6][:], '-c', label=str_1[6][:],marker='.', markerfacecolor='k', markersize=6)
    plt.plot(x,perf[7][:],color=[0.81, 0.3, 0.6], label=str_1[7][:],marker='.', markerfacecolor='k', markersize=6)

    #plt.title("Performance Statistics")
    plt.xlabel(xlab)
    plt.ylabel(ylab)
    plt.legend(bbox_to_anchor=(1.05, 1.0), loc='upper left')
    plt.tight_layout()
    plt.savefig(str(dd)+'_'+str(tt)+'_'+str(val)+'_'+'Graph.png', dpi = 800)
    plt.show(block=False)
    plt.close(val)
    return perf
def Complete_Figure_11(x,perf,val,str_1,xlab,ylab,tt):
    # VALLL=np.column_stack((y0,y1,y2,y3,y4))
    # perf=Perf_est_all_final(VALLL)
    perf=perf*100
    np.savetxt(str(val)+'_'+str(tt)+'_'+'Graph.csv', perf, delimiter=",")
    # data to plot
    n_groups = 6
    # create plot
    fig, ax = plt.subplots()
    index = np.arange(n_groups)
    bar_width = 0.15
    opacity = 0.8
    rects1 = plt.bar(index, perf[0][:], bar_width,alpha=opacity,color='b',label=str_1[0][:])
    rects2 = plt.bar(index + bar_width, perf[1][:], bar_width,alpha=opacity,color='g',label=str_1[1][:])
    rects3 = plt.bar(index + 2*bar_width, perf[2][:], bar_width,alpha=opacity,color='r',label=str_1[2][:])
    rects4 = plt.bar(index + 3*bar_width, perf[3][:], bar_width,alpha=opacity,color='y',label=str_1[3][:])
    rects5 = plt.bar(index + 4*bar_width, perf[4][:], bar_width,alpha=opacity,color='m',label=str_1[4][:])

    plt.xlabel(xlab)
    plt.ylabel(ylab)
    # plt.title('Scores by person')
    plt.xticks(index + bar_width, ('5', '6', '7', '8','9','10'))
    plt.legend(loc='lower left')
    # plt.tight_layout()
    # plt.show()
    plt.savefig(str(val)+'_'+str(tt)+'_'+'Graph.png', dpi = 800)
    plt.show(block=False)
def Perf_plot_Complete_final(tt,ii,dt):
    # dt=1
    [A, B, C, D, E,F,G,H] = load_perf_value_saved_Algo_Analysis(tt,dt)
    if dt==1:
        xlab = "Training Percentage(%)"
        x = np.asarray([40, 50, 60, 70, 80]).T
        [Perf_1, Perf_2, Perf_3, Perf_4, Perf_5, Perf_6, Perf_7, Perf_8, Perf_9, Perf_10,
         Perf_11] = Main_perf_val_acc_sen_spe(A, B, C, D, E, F, G, H, tt)
    elif dt==2:
        xlab = "K-Fold"
        x = np.asarray([5,6,7,8,9,10]).T
        [Perf_1, Perf_2, Perf_3, Perf_4, Perf_5, Perf_6, Perf_7, Perf_8, Perf_9, Perf_10,
         Perf_11] = Main_perf_val_acc_sen_spe(A, B, C, D, E, F, G, H, tt)
    else:
        xlab = "FPR(%)"
        x = np.asarray([0,10,20,30,40,50,60,70,80,90,100]).T
        [Perf_A, Perf_2, Perf_3, Perf_4, Perf_5, Perf_6, Perf_7, Perf_8, Perf_9, Perf_10,
         Perf_11] = Main_perf_val_acc_sen_spe(A, B, C, D, E, F, G, H, tt)
        Perf_1 =np.zeros((8, 11))
        try:
            if tt!=2:
                Perf_1[:,1:10]=Perf_A
            else:
                Perf_1[:, 1:8] = Perf_A
                Perf_1[:, 8] = Perf_A[:,-2]
                Perf_1[:, 9] = Perf_A[:,-1]
                Perf_1[:, 10] = Perf_A[:,-1]
                Perf_1[Perf_1 <= 0.1] = 0.75
        except:
            Perf_1=Perf_A
            Perf_1[Perf_1<=0.1]=0.75
        Perf_1[:, 0] = [0,0,0,0,0,0,0,0]
        Perf_1[:,-1]=[1,1,1,1,1,1,1,1]
        ylab = "TPR(%)"
        str_1 = ["Elstream [2]", "PWPAE [5]", "BDDM [6]", "Aggregate density-based concept drift identification [7]", "DBN", "LSTM", "RNN", "OKW + Intelligent preying-based Hybrid deep classifier"]
        ACC0=Complete_Figure_1(x, Perf_1, ii, str_1, xlab, ylab,tt,dt)
    # ################ fig 1:3  ##################################################
    str_1 = ["Elstream [2]", "PWPAE [5]", "BDDM [6]", "Aggregate density-based concept drift identification [7]", "DBN",
             "LSTM", "RNN", "OKW + Intelligent preying-based Hybrid deep classifier"]
    if dt<=2:
        try:
            ylab = "Accuracy(%)"
            ACC0=Complete_Figure_1(x, Perf_1, ii, str_1, xlab, ylab,tt,dt)
            ylab = "Sensitivity(%)"
            ii=ii+1
            SEN0=Complete_Figure_1(x, Perf_2, ii, str_1, xlab, ylab,tt,dt)
            ylab = "Specificity(%)"
            ii=ii+1
            SPE0=Complete_Figure_1(x, Perf_3, ii, str_1, xlab, ylab,tt,dt)
            ylab = "Precision(%)"
            ii=ii+1
            SPE1=Complete_Figure_1(x, Perf_4, ii, str_1, xlab, ylab,tt,dt)
            ylab = "F-Measure(%)"
            ii=ii+1
            SPE3=Complete_Figure_1(x, Perf_6, ii, str_1, xlab, ylab,tt,dt)
        except:
            x = np.asarray([ 6, 7, 8, 9, 10]).T
            ylab = "Accuracy(%)"
            ACC0=Complete_Figure_1(x, Perf_1, ii, str_1, xlab, ylab,tt,dt)
            ylab = "Sensitivity(%)"
            ii=ii+1
            SEN0=Complete_Figure_1(x, Perf_2, ii, str_1, xlab, ylab,tt,dt)
            ylab = "Specificity(%)"
            ii=ii+1
            SPE0=Complete_Figure_1(x, Perf_3, ii, str_1, xlab, ylab,tt,dt)
            ylab = "Precision(%)"
            ii=ii+1
            SPE1=Complete_Figure_1(x, Perf_4, ii, str_1, xlab, ylab,tt,dt)
            ylab = "F-Measure(%)"
            ii=ii+1
            SPE3=Complete_Figure_1(x, Perf_6, ii, str_1, xlab, ylab,tt,dt)
def Perf_plot_Complete_final_New(ii):
    [A, B, C, D, E,F,G] = load_perf_value_saved_Algo_Analysis(1)
    [Perf_11,Perf_21,Perf_31,Perf_41,Perf_51,Perf_61,Perf_71,Perf_81,Perf_91,Perf_101]=Main_perf_val_acc_sen_spe(A, B, C, D, E,F,G,tt)
    [A, B, C, D, E,F,G] = load_perf_value_saved_Algo_Analysis(2)
    [Perf_12,Perf_22,Perf_32,Perf_42,Perf_52,Perf_62,Perf_72,Perf_82,Perf_92,Perf_102]=Main_perf_val_acc_sen_spe(A, B, C, D, E,F,G,tt)
    [A, B, C, D, E,F,G] = load_perf_value_saved_Algo_Analysis(3)
    [Perf_13,Perf_23,Perf_33,Perf_43,Perf_53,Perf_63,Perf_73,Perf_83,Perf_93,Perf_103]=Main_perf_val_acc_sen_spe(A, B, C, D, E,F,G,tt)
    [A, B, C, D, E,F,G] = load_perf_value_saved_Algo_Analysis(4)
    [Perf_14,Perf_24,Perf_34,Perf_44,Perf_54,Perf_64,Perf_74,Perf_84,Perf_94,Perf_104]=Main_perf_val_acc_sen_spe(A, B, C, D, E,F,G,tt)
    Perf_1=[np.mean(Perf_11,axis=1),np.mean(Perf_12,axis=1),np.mean(Perf_13,axis=1),np.mean(Perf_14,axis=1)]
    Perf_2=[np.mean(Perf_21,axis=1),np.mean(Perf_22,axis=1),np.mean(Perf_23,axis=1),np.mean(Perf_24,axis=1)]
    Perf_3=[np.mean(Perf_31,axis=1),np.mean(Perf_32,axis=1),np.mean(Perf_33,axis=1),np.mean(Perf_34,axis=1)]
    Perf_4=[np.mean(Perf_41,axis=1),np.mean(Perf_42,axis=1),np.mean(Perf_43,axis=1),np.mean(Perf_44,axis=1)]
    Perf_5=[np.mean(Perf_51,axis=1),np.mean(Perf_52,axis=1),np.mean(Perf_53,axis=1),np.mean(Perf_54,axis=1)]
    Perf_6=[np.mean(Perf_61,axis=1),np.mean(Perf_62,axis=1),np.mean(Perf_63,axis=1),np.mean(Perf_64,axis=1)]
    Perf_7=[np.mean(Perf_71,axis=1),np.mean(Perf_72,axis=1),np.mean(Perf_73,axis=1),np.mean(Perf_74,axis=1)]
    Perf_8=[np.mean(Perf_81,axis=1),np.mean(Perf_82,axis=1),np.mean(Perf_83,axis=1),np.mean(Perf_84,axis=1)]
    Perf_9=[np.mean(Perf_91,axis=1),np.mean(Perf_92,axis=1),np.mean(Perf_93,axis=1),np.mean(Perf_94,axis=1)]
    Perf_10=[np.mean(Perf_101,axis=1),np.mean(Perf_102,axis=1),np.mean(Perf_103,axis=1),np.mean(Perf_104,axis=1)]
    Perf_1 = np.asarray(Perf_1)
    Perf_2 = np.asarray(Perf_2)
    Perf_3 = np.asarray(Perf_3)
    Perf_4 = np.asarray(Perf_4)
    Perf_5 = np.asarray(Perf_5)
    Perf_6 = np.asarray(Perf_6)
    Perf_7 = np.asarray(Perf_7)
    Perf_8 = np.asarray(Perf_8)
    Perf_9 = np.asarray(Perf_9)
    Perf_10 = np.asarray(Perf_10)
   # ################ fig 1:3  ##################################################
    # str_1 = ["RF [29]","DT [30]","SVM [31]","DCNN [32]","DCNN MS [27]","DCNN MBO [26]","BM-MSA"]
    str_1 = ["HANP [6]","CHAN [7]","K-NN: Term Similarity [5]","K-NN: Sentiment Similarity [5]","GWO+NN [26]","NN [28]","IGWO"]

    x = np.asarray([40, 50, 60, 70, 80]).T
    xlab = "Test Domain"
    ylab = "Accuracy(%)"
    ACC0=Complete_Figure_1_new(x, Perf_1, ii, str_1, xlab, ylab,tt)
    ylab = "Sensitivity(%)"
    ii=ii+1
    SEN0=Complete_Figure_1_new(x, Perf_2, ii, str_1, xlab, ylab,tt)
    ylab = "Specificity(%)"
    ii=ii+1
    SPE0=Complete_Figure_1_new(x, Perf_3, ii, str_1, xlab, ylab,tt)
    ylab = "Precision(%)"
    ii=ii+1
    SPE1=Complete_Figure_1_new(x, Perf_4, ii, str_1, xlab, ylab,tt)
    ylab = "Recall(%)"
    ii=ii+1
    SPE2=Complete_Figure_1_new(x, Perf_5, ii, str_1, xlab, ylab,tt)
    ylab = "F-Measure(%)"
    ii=ii+1
    SPE3=Complete_Figure_1_new(x, Perf_6, ii, str_1, xlab, ylab,tt)
    ylab = "TS(%)"
    ii=ii+1
    SPE4=Complete_Figure_1_new(x, Perf_7, ii, str_1, xlab, ylab,tt)
    ylab = "NPV(%)"
    ii=ii+1
    SPE5=Complete_Figure_1_new(x, Perf_8, ii, str_1, xlab, ylab,tt)
    ylab = "FOR(%)"
    ii=ii+1
    SPE6=Complete_Figure_1_new(x, Perf_9, ii, str_1, xlab, ylab,tt)
    ylab = "MCC(%)"
    ii=ii+1
    SPE7=Complete_Figure_1_new(x, Perf_10, ii, str_1, xlab, ylab,tt)
def entropy(data, bins=100):
    hist = np.histogramdd(data, bins=bins)[0]
    prob = hist/len(data)
    prob[prob == 0] = 1
    log_prob = np.log2(prob)
    return -np.sum(np.multiply(prob, log_prob))
def gini(x):
    # Mean absolute difference
    mad = np.abs(np.subtract.outer(x, x)).mean()
    # Relative mean absolute difference
    rmad = mad/np.mean(x)
    # Gini coefficient
    g = 0.5 * rmad
    return g
def holo_entropy(data, bins=100):
    hist = np.histogramdd(data, bins=bins)[0]
    prob = hist/len(data)
    prob[prob == 0] = 1
    log_prob = np.log2(prob)
    ent=-np.sum(np.multiply(prob, log_prob))
    weight=2*(1-(1/(1+np.exp(-1*ent))))
    hent=ent*weight
    return hent
import pandas as pd
import numpy as np

def ewma(x, alpha):
    # Coerce x to an array
    x = np.array(x)
    n = x.size
    # Create an initial weight matrix of (1-alpha), and a matrix of powers
    # to raise the weights by
    w0 = np.ones(shape=(n,n)) * (1-alpha)
    p = np.vstack([np.arange(i,i-n,-1) for i in range(n)])
    # Create the weight matrix
    w = np.tril(w0**p,0)
    # Calculate the ewma
    return np.dot(w, x[::np.newaxis]) / w.sum(axis=1)
def gain(d):
    '''
    return the information gain:
    gain(D, A) = entropy(D)−􏰋 SUM ( |Di| / |D| * entropy(Di) )
    '''

    # total = 0
    # for v in a:
    total =sum(d) /(sum(d) * entropy(d))
    gain = entropy(d) - total
    return gain
def main_feat_ext_all(sel_feat):
    En = holo_entropy(sel_feat, bins=100)
    # QW = ewma(x=sel_feat, alpha=0.55)
    # QW = QW.mean()
    stats = Statistics(sel_feat)
    f11=gini(sel_feat)
    # oddsratio, pvalue = stats1.fisher_exact(sel_feat)
    f0= chisquare(sel_feat)
    f12=gain(sel_feat)
    f1 = stats.mean()
    f2 = stats.variance()
    f3 = stats.skewness()
    f4 = stats.kurtosis()
    f5 = perm_entropy(sel_feat, order=3, normalize=True)  # Permutation entropy
    f6 = spectral_entropy(sel_feat, 100, method='welch', normalize=True)  # Spectral entropy
    f7 = svd_entropy(sel_feat, order=3, delay=1, normalize=True)  # Singular value decomposition entropy
    f8 = app_entropy(sel_feat, order=2, metric='chebyshev')  # Approximate entropy
    f9 = sample_entropy(sel_feat, order=2, metric='chebyshev')  # Sample entropy
    feat=np.nan_to_num(np.asarray([En,f11,f0.statistic,f0.pvalue,f12,f1,f2,f3,f4,f5,f6,f7,f8,f9]))
    return feat
from opfunu.cec_basic.cec2014_nobias import *
import BSO
import SARO
import SARO_MOD
def Main_FS_OPT_Final(Feat,sel_feat,opt):
    ## Setting parameters
    obj_func = F1
    lb = [-100]
    ub = [100]
    problem_size = sel_feat
    batch_size = 50
    verbose = True
    epoch = 100
    pop_size = 25
    OD=Feat.shape[1]
    if opt==1:
        md1 = BSO.BaseBSO(obj_func, lb, ub, problem_size, batch_size, verbose, epoch, pop_size, m=5, p1=0.2, p2=0.8,
                          p3=0.4, p4=0.5, k=20, miu=0, xichma=1, OD=OD)
    elif opt==2:
        md1 = SARO.BaseSARO(obj_func, lb, ub, problem_size=100, batch_size=10, verbose=True, epoch=50, pop_size=25,
                            se=0.5, mu=50, OD=OD)
    else:
        md1 = SARO_MOD.BaseSARO_MOD(obj_func, lb, ub, problem_size=100, batch_size=10, verbose=True,epoch=50, pop_size=25, se=0.5, mu=50,OD=OD)
    best_pos1, best_fit1, list_loss1,sel_feat = md1.train()
    return sel_feat
#########################################################
########################################################
# import PySimpleGUI as sg
# VVV=sg.PopupYesNo('Do You want Complete Execution?')
# VVV= "Yes"
# if (VVV == "Yes"):
#     [index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab] = Main_Data_Feature_Extraction_All("HDFS_2k.log")
#     Perf_Evaluation_save_all_final(index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab, 1)
#     [index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab] = Main_Data_Feature_Extraction_All("Apache_2k.log")
#     Perf_Evaluation_save_all_final(index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab, 2)
#     [index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab] = Main_Data_Feature_Extraction_All("Hadoop_2k.log")
#     Perf_Evaluation_save_all_final(index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab, 3)
#     [index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab] = Main_Data_Feature_Extraction_All("Linux_2k.log")
#     Perf_Evaluation_save_all_final(index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab, 4)
#     [index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab] = Main_Data_Feature_Extraction_All("Windows_2k.log")
#     Perf_Evaluation_save_all_final(index_0, index_1, Feat,Feat_0,Feat_1,Feat_2, df_event, Lab, 5)
#     tt=0
#     for ii in range(1,5):
#         Perf_plot_Complete_final(ii, tt)
#         tt = tt + 10
# else:
#     tt=0
#     Perf_plot_Complete_final_New(tt)
#     for ii in range(1,5):
#         Perf_plot_Complete_final(ii, tt)
#         tt=tt+10