#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri May 10 15:08:16 2019

@author: ankitachikodi
"""


EMAIL_ADDR = "thakkararkil3@gmail.com"