"""
Description : This file implements the function to evaluation accuracy of log parsing
Author      : LogPAI team
License     : MIT
"""

import sys
import pandas as pd
from collections import defaultdict
import scipy.misc
from scipy import special as spp
import numpy as np

def evaluate(groundtruth, parsedresult,ii):
    """ Evaluation function to benchmark log parsing accuracy

    Arguments
    ---------
        groundtruth : str
            file path of groundtruth structured csv file
        parsedresult : str
            file path of parsed structured csv file

    Returns
    -------
        f_measure : float
        accuracy : float
    """
    df_groundtruth = pd.read_csv(groundtruth)
    # df_parsedlog = pd.read_csv(parsedresult)
    # Remove invalid groundtruth event Ids
    null_logids = df_groundtruth[~df_groundtruth['EventId'].isnull()].index
    df_groundtruth = df_groundtruth.loc[null_logids]
    # df_parsedlog = df_parsedlog.loc[null_logids]
    import  Test_main_1 as tm
    Feat = df_groundtruth['EventId'].values
    # feature_extractor = tm.FeatureExtractor()
    # Feat = feature_extractor.fit_transform(Feat, term_weighting='tf-idf')
    LAB=[]
    for tq in range(0,len(df_groundtruth)):
        if ii==0:
         Con=(df_groundtruth['EventId'][tq] == 'E6')*1
        elif ii == 1:
         Con = (df_groundtruth['EventId'][tq] == 'E17') * 1
        elif ii==2:
            Con = (df_groundtruth['EventId'][tq] == 'E10') * 1
        elif ii==3:
            Con = (df_groundtruth['EventId'][tq] == 'E18') * 1
        else:
            Con = (df_groundtruth['EventId'][tq] == 'E18') * 1
        LAB.append(Con)
    Lab=np.asarray(LAB)
    feature_extractor = tm.FeatureExtractor()
    Feat = feature_extractor.fit_transform(Feat, term_weighting='tf-idf')
    Feat_1=[]
    for tq in range(0,Feat.shape[0]):
        Feat_1.append(tm.main_feat_ext_all(Feat[tq,:]).reshape(1,-1))
    Feat_11=np.asarray(Feat_1).reshape(len(Feat_1),Feat_1[0].shape[1])
    Feat=np.hstack((Feat,Feat_11))
    Feat = Feat / Feat.max()
    # tot_sel_feat=Feat.shape[1]-5
    # Sel_Feat_1=tm.Main_FS_OPT_Final(Feat, tot_sel_feat, 1)
    # Sel_Feat_2=tm.Main_FS_OPT_Final(Feat, tot_sel_feat, 2)
    # Sel_Feat_3=tm.Main_FS_OPT_Final(Feat, tot_sel_feat, 3)
    # Feat_0=Feat[:,Sel_Feat_1]
    # Feat_1=Feat[:,Sel_Feat_2]
    # Feat_2=Feat[:,Sel_Feat_3]


    # iik=0
    # win_size=5
    # Fin_feat=[]
    # Fin_lab=[]
    # for ti in range(0,5000):
    #     tem_win=Feat[iik:iik+win_size,:]
    #     tem_lab=Lab[iik:iik+win_size]
    #     # if tem_win.shape[0]!=win_size:
    #     #     we=45
    #     curr_th = tem_win.mean()
    #     if ti==0:
    #         Fin_feat.append(tem_win)
    #         Fin_lab.append(tem_lab)
    #         old_th=tem_win.mean()
    #     else:
    #         if curr_th!=old_th:
    #             Fin_feat.append(tem_win)
    #             Fin_lab.append(tem_lab)
    #             old_th = tem_win.mean()
    #         else:
    #             old_th = tem_win.mean()
    #     iik=iik+1
    #     if ti>=1990:
    #         iik=0
    # Fin_feat1=np.array(Fin_feat)
    # Fin_lab1=np.array(Fin_lab)
    # Fin_feat1=np.reshape(Fin_feat1,(Fin_feat1.shape[0]*Fin_feat1.shape[1],Fin_feat1.shape[2]))
    # Fin_lab1=np.reshape(Fin_lab1,(Fin_feat1.shape[0],))
    index = np.where(Lab == 1)
    index_1 = index[0]
    index = np.where(Lab == 0)
    index_0 = index[0]
    return [index_0,index_1,Feat,parsedresult,Lab]

def get_accuracy(series_groundtruth, series_parsedlog, debug=False):
    """ Compute accuracy metrics between log parsing results and ground truth

    Arguments
    ---------
        series_groundtruth : pandas.Series
            A sequence of groundtruth event Ids
        series_parsedlog : pandas.Series
            A sequence of parsed event Ids
        debug : bool, default False
            print error log messages when set to True

    Returns
    -------
        precision : float
        recall : float
        f_measure : float
        accuracy : float
    """
    series_groundtruth_valuecounts = series_groundtruth.value_counts()
    real_pairs = 0
    for count in series_groundtruth_valuecounts:
        if count > 1:
            real_pairs += spp.comb(count, 2)
    series_parsedlog_valuecounts = series_parsedlog.value_counts()
    parsed_pairs = 0
    for count in series_parsedlog_valuecounts:
        if count > 1:
            parsed_pairs += spp.comb(count, 2)

    accurate_pairs = 0
    accurate_events = 0  # determine how many lines are correctly parsed
    for parsed_eventId in series_parsedlog_valuecounts.index:
        logIds = series_parsedlog[series_parsedlog == parsed_eventId].index
        series_groundtruth_logId_valuecounts = series_groundtruth[logIds].value_counts()
        error_eventIds = (parsed_eventId, series_groundtruth_logId_valuecounts.index.tolist())
        error = True
        if series_groundtruth_logId_valuecounts.size == 1:
            groundtruth_eventId = series_groundtruth_logId_valuecounts.index[0]
            if logIds.size == series_groundtruth[series_groundtruth == groundtruth_eventId].size:
                accurate_events += logIds.size
                error = False
        if error and debug:
            print('(parsed_eventId, groundtruth_eventId) =', error_eventIds, 'failed', logIds.size, 'messages')
        for count in series_groundtruth_logId_valuecounts:
            if count > 1:
                accurate_pairs += spp.comb(count, 2)

    precision = float(accurate_pairs) / parsed_pairs
    recall = float(accurate_pairs) / real_pairs
    f_measure = 2 * precision * recall / (precision + recall)
    accuracy = float(accurate_events) / series_groundtruth.size
    return precision, recall, f_measure, accuracy







