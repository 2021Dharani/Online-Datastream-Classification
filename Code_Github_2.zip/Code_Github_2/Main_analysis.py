#!/usr/bin/env python

import sys
# sys.path.append('../')
from logparser.LogMine import LogMine
from logparser.utils import Eval_Mod
import numpy as np
import os
import pandas as pd
import Test_main_1 as tm

input_dir = 'logs/'  # The input directory of log file
output_dir = 'LogMine_result/'  # The output directory of parsing results

benchmark_settings = {
    'Apache': {
        'log_file': 'Apache/Apache_2k.log',
        'log_format': '\[<Time>\] \[<Level>\] <Content>',
        'regex': [r'(\d+\.){3}\d+'],
        'max_dist': 0.005,
        'k': 1,
        'levels': 2
    },
    'Hadoop': {
        'log_file': 'Hadoop/Hadoop_2k.log',
        'log_format': '<Date> <Time> <Level> \[<Process>\] <Component>: <Content>',
        'regex': [r'(\d+\.){3}\d+'],
        'max_dist': 0.005,
        'k': 1,
        'levels': 2
    },
    'Spark': {
        'log_file': 'Spark/Spark_2k.log',
        'log_format': '<Date> <Time> <Level> <Component>: <Content>',
        'regex': [r'(\d+\.){3}\d+', r'\b[KGTM]?B\b', r'([\w-]+\.){2,}[\w-]+'],
        'max_dist': 0.01,
        'k': 1,
        'levels': 2
    },
    'Linux': {
        'log_file': 'Linux/Linux_2k.log',
        'log_format': '<Month> <Date> <Time> <Level> <Component>(\[<PID>\])?: <Content>',
        'regex': [r'(\d+\.){3}\d+', r'\d{2}:\d{2}:\d{2}'],
        'max_dist': 0.006,
        'k': 1,
        'levels': 2
    },
    'E_Commerce': {
        'log_file': 'ecommerce-api-incoming-rps/api-01.csv',
        'log_format': '<TimeStamp> <Value> <Label>',
        'regex': [r'(\d+\.){3}\d+', r'\d{2}:\d{2}:\d{2}'],
        'max_dist': 0.006,
        'k': 1,
        'levels': 2
    },
    # 'Zookeeper': {
    #     'log_file': 'Zookeeper/Zookeeper_2k.log',
    #     'log_format': '<Date> <Time> - <Level>  \[<Node>:<Component>@<Id>\] - <Content>',
    #     'regex': [r'(/|)(\d+\.){3}\d+(:\d+)?'],
    #     'max_dist': 0.001,
    #     'k': 1,
    #     'levels': 2
    # },
}
import PySimpleGUI as sg
VVV=sg.PopupYesNo('Do You want Complete Execution?')
# https://github.com/microsoft/cloud-monitoring-dataset
# VVV='No'
if (VVV == "Yes"):
    bechmark_result = []
    ii=0
    for dataset, setting in benchmark_settings.items():
        print('\n=== Evaluation on %s ===' % dataset)
        if dataset=='E_Commerce':
                df_groundtruth = pd.read_csv(setting['log_file'])
                Feat=df_groundtruth.values[:,1]
                Lab = df_groundtruth.values[:, 2]
                index = np.where(Lab == 1)
                index_1 = index[0]
                index = np.where(Lab == 0)
                index_0 = index[0]
                parsedresult='df'
                try:
                    feature_extractor = tm.FeatureExtractor()
                    Feat = feature_extractor.fit_transform(Feat, term_weighting='tf-idf')
                    Feat_1 = []
                    for tq in range(0, Feat.shape[0]):
                        Feat_1.append(tm.main_feat_ext_all(int(Feat[tq,])).reshape(1, -1))
                    Feat_11 = np.asarray(Feat_1).reshape(len(Feat_1), Feat_1[0].shape[1])
                    Feat = np.hstack((Feat, Feat_11))
                except:
                    AA = [Feat, Feat,Feat, Feat,Feat,Feat, Feat,Feat, Feat,Feat,Feat, Feat,Feat, Feat,Feat,Feat, Feat,Feat, Feat,Feat,Feat, Feat,Feat, Feat,Feat]
                    Feat=np.transpose(np.array(AA))
                Feat = Feat / Feat.max()
        else:
            indir = os.path.join(input_dir, os.path.dirname(setting['log_file']))
            log_file = os.path.basename(setting['log_file'])
            parser = LogMine.LogParser(log_format=setting['log_format'], indir=indir, outdir=output_dir,rex=setting['regex'], max_dist=setting['max_dist'], k=setting['k'],levels=setting['levels'])
            parser.parse(log_file)
            [index_0, index_1, Feat,  parsedresult, Lab] = Eval_Mod.evaluate(groundtruth=os.path.join(indir, log_file + '_structured.csv'),parsedresult=os.path.join(output_dir, log_file + '_structured.csv'),ii=ii)

        tm.Perf_Evaluation_save_all_final(index_0, index_1, Feat.astype(float),  parsedresult, Lab.astype(int), ii)
        tm.Perf_Evaluation_save_all_final_K_Fold(index_0, index_1, Feat.astype(float),  parsedresult, Lab.astype(int), ii)
        tm.Perf_Evaluation_save_all_final_Roc(index_0, index_1, Feat.astype(float),  parsedresult, Lab.astype(int), ii)

        ii=ii+1

    tt=0
    for ii in range(0,5):
        print(ii)
        tm.Perf_plot_Complete_final(ii, tt,1)
        tm.Perf_plot_Complete_final(ii, tt, 2)
        tm.Perf_plot_Complete_final(ii, tt, 3)
        tt = tt + 5
else:
    tt=0
    for ii in range(4,5):
        print(ii)
        tm.Perf_plot_Complete_final(ii, tt,1)
        tm.Perf_plot_Complete_final(ii, tt, 2)
        tm.Perf_plot_Complete_final(ii, tt, 3)
        tt = tt + 5